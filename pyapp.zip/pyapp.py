from pickletools import optimize
import random

exit = False

user_points = 0
computer_points = 0

while exit == False:
    options = ['rock', 'paper', 'scissors']
    user_input = input('Choose rock, paper or scissors: ')
    computer_input = random.choice(options)
    
    if user_input == "exit":
        print('Game Ended')
        print(f"You won a total score of {int(user_points)} points and the computer score is {int(computer_points)} points")
        exit = True
        
    if user_input == "rock":
        if computer_input == 'rock':
            print('your input is rock')
            print('computer_input is rock')
            print("it's  a tie")
        elif computer_input == 'paper':
            print('your input is rock ')
            print('computer_input is paper')
            print("computer wins!!!")
            computer_points += 1
        elif computer_input == 'scissors':
            print('your input is rock ')
            print('computer_input is scissors')
            print("user wins!!!")
            user_points += 1
    elif user_input == "paper":
        if computer_input == 'paper':
            print('your input is paper')
            print('computer_input is paper')
            print("it's a tie")
        elif computer_input == 'rock':
            print('your input is paper')
            print('computer_input is rock')
            print("user wins!!!")
            user_points += 1
        elif computer_input == 'scissors':
            print('your input is paper')
            print('computer_input is scissors')
            print("computer wins!!!")
            computer_points += 1
    elif user_input == "scissors":
        if computer_input == 'scissors':
            print('your input is scissors')
            print("computer_input is scissors")
            print("it's a tie")
        elif computer_input == 'rock':
            print("your input is scissors")
            print('computer_input is rock')
            print("computer wins!!!")
            computer_points += 1
        elif computer_input == 'paper':
            print("your input is scissors")
            print('computer_input is paper')
            print("user wins!!!")
            user_points += 1
        elif user_input != "rock" or user_input != 'paper' or user_input != 'scissors':
            print("invalid input")